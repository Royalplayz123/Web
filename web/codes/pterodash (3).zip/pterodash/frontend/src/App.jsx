import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './lib/store';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Servers from './pages/Servers';
import Store from './pages/Store';
import Tickets from './pages/Tickets';
import Admin from './pages/Admin';
import { NotificationsPage, SettingsPage } from './pages/Settings';
import { LoginPage, RegisterPage } from './pages/Auth';

function Layout({ children }) {
  const { pathname } = useLocation();
  return (
    <div className="flex min-h-screen bg-grid" style={{ background: '#060810' }}>
      <Sidebar />
      <main className="flex-1 ml-56 p-6 lg:p-8 min-h-screen">
        <div key={pathname} className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function AuthGuard({ children }) {
  const { user, loading } = useAuthStore();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#060810' }}>
        <div className="text-center space-y-4">
          <div className="text-5xl">🐲</div>
          <div className="w-8 h-8 rounded-full border-2 border-blue-500/30 border-t-blue-500 animate-spin mx-auto" />
          <p className="text-slate-500 text-sm">Loading PteroDash...</p>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function AdminGuard({ children }) {
  const { user } = useAuthStore();
  if (user?.role !== 'admin') return <Navigate to="/dashboard" replace />;
  return children;
}

export default function App() {
  const { fetchMe } = useAuthStore();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) fetchMe();
    else useAuthStore.setState({ loading: false });
  }, []);

  return (
    <BrowserRouter>
      <Toaster position="bottom-right" toastOptions={{ duration: 4000, style: { background: '#111827', border: '1px solid rgba(59,130,246,0.2)', color: '#f1f5f9', fontFamily: 'DM Sans, sans-serif' } }} />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/" element={<Navigate to="/dashboard" replace />} />

        <Route path="/dashboard" element={<AuthGuard><Layout><Dashboard /></Layout></AuthGuard>} />
        <Route path="/servers" element={<AuthGuard><Layout><Servers /></Layout></AuthGuard>} />
        <Route path="/store" element={<AuthGuard><Layout><Store /></Layout></AuthGuard>} />
        <Route path="/tickets" element={<AuthGuard><Layout><Tickets /></Layout></AuthGuard>} />
        <Route path="/notifications" element={<AuthGuard><Layout><NotificationsPage /></Layout></AuthGuard>} />
        <Route path="/settings" element={<AuthGuard><Layout><SettingsPage /></Layout></AuthGuard>} />
        <Route path="/admin" element={<AuthGuard><AdminGuard><Layout><Admin /></Layout></AdminGuard></AuthGuard>} />

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
