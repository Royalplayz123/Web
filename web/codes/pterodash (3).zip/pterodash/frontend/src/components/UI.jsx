// ── StatCard ──────────────────────────────────────────────────────────────
export function StatCard({ icon, label, value, sub, color = '#3b82f6', trend }) {
  return (
    <div className="glass-card rounded-2xl p-5 relative overflow-hidden group cursor-default">
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{ background: `radial-gradient(circle at top left, ${color}08, transparent 60%)` }} />
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#64748b' }}>{label}</p>
          <p className="font-display font-black text-3xl text-white">{value}</p>
          {sub && <p className="text-xs mt-1" style={{ color: '#64748b' }}>{sub}</p>}
        </div>
        <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-xl flex-shrink-0"
          style={{ background: `${color}18`, border: `1px solid ${color}30`, boxShadow: `0 0 20px ${color}15` }}>
          {icon}
        </div>
      </div>
      {trend !== undefined && (
        <div className={`mt-3 text-xs font-semibold flex items-center gap-1 ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}% this week
        </div>
      )}
    </div>
  );
}

// ── ProgressBar ────────────────────────────────────────────────────────────
export function ResourceBar({ label, used, total, unit = 'MB', color }) {
  const pct = total > 0 ? Math.min(100, Math.round((used / total) * 100)) : 0;
  const auto = pct > 85 ? '#ef4444' : pct > 65 ? '#f59e0b' : '#3b82f6';
  const c = color || auto;
  return (
    <div>
      <div className="flex justify-between items-center mb-1.5">
        <span className="text-xs font-semibold" style={{ color: '#94a3b8' }}>{label}</span>
        <span className="text-xs font-mono" style={{ color: '#64748b' }}>
          {used.toLocaleString()} / {total.toLocaleString()} {unit}
        </span>
      </div>
      <div className="progress-track h-1.5">
        <div className="progress-fill" style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${c}, ${c}cc)`, boxShadow: `0 0 8px ${c}60` }} />
      </div>
    </div>
  );
}

// ── Badge ──────────────────────────────────────────────────────────────────
const badgeColors = {
  running:      { bg: 'rgba(34,197,94,0.12)',  text: '#4ade80',  border: 'rgba(34,197,94,0.25)' },
  online:       { bg: 'rgba(34,197,94,0.12)',  text: '#4ade80',  border: 'rgba(34,197,94,0.25)' },
  offline:      { bg: 'rgba(239,68,68,0.12)',  text: '#f87171',  border: 'rgba(239,68,68,0.25)' },
  starting:     { bg: 'rgba(245,158,11,0.12)', text: '#fbbf24',  border: 'rgba(245,158,11,0.25)' },
  installing:   { bg: 'rgba(139,92,246,0.12)', text: '#a78bfa',  border: 'rgba(139,92,246,0.25)' },
  suspended:    { bg: 'rgba(239,68,68,0.12)',  text: '#f87171',  border: 'rgba(239,68,68,0.25)' },
  open:         { bg: 'rgba(59,130,246,0.12)', text: '#60a5fa',  border: 'rgba(59,130,246,0.25)' },
  answered:     { bg: 'rgba(139,92,246,0.12)', text: '#a78bfa',  border: 'rgba(139,92,246,0.25)' },
  user_replied: { bg: 'rgba(245,158,11,0.12)', text: '#fbbf24',  border: 'rgba(245,158,11,0.25)' },
  closed:       { bg: 'rgba(107,114,128,0.12)',text: '#9ca3af',  border: 'rgba(107,114,128,0.25)' },
  active:       { bg: 'rgba(34,197,94,0.12)',  text: '#4ade80',  border: 'rgba(34,197,94,0.25)' },
  banned:       { bg: 'rgba(239,68,68,0.12)',  text: '#f87171',  border: 'rgba(239,68,68,0.25)' },
  admin:        { bg: 'rgba(251,146,60,0.12)', text: '#fb923c',  border: 'rgba(251,146,60,0.25)' },
  user:         { bg: 'rgba(107,114,128,0.12)',text: '#9ca3af',  border: 'rgba(107,114,128,0.25)' },
  low:          { bg: 'rgba(34,197,94,0.12)',  text: '#4ade80',  border: 'rgba(34,197,94,0.25)' },
  medium:       { bg: 'rgba(245,158,11,0.12)', text: '#fbbf24',  border: 'rgba(245,158,11,0.25)' },
  high:         { bg: 'rgba(239,68,68,0.12)',  text: '#f87171',  border: 'rgba(239,68,68,0.25)' },
  critical:     { bg: 'rgba(239,68,68,0.2)',   text: '#ef4444',  border: 'rgba(239,68,68,0.4)' },
};

export function Badge({ status, label, dot = true }) {
  const c = badgeColors[status] || badgeColors.user;
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: c.bg, color: c.text, border: `1px solid ${c.border}` }}>
      {dot && status === 'running' && (
        <span className="status-dot-running w-1.5 h-1.5 rounded-full inline-block" style={{ background: c.text }} />
      )}
      {label || status}
    </span>
  );
}

// ── Modal ──────────────────────────────────────────────────────────────────
export function Modal({ title, onClose, children, width = 500 }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="glass-card rounded-2xl overflow-hidden animate-slide-up" style={{ width: '100%', maxWidth: width }}>
        <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
          <h2 className="font-display font-bold text-lg text-white">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all text-lg">×</button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

// ── Table ──────────────────────────────────────────────────────────────────
export function Table({ headers, children, empty = 'No data' }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
            {headers.map((h) => (
              <th key={h} className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wider" style={{ color: '#64748b' }}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {children || (
            <tr>
              <td colSpan={headers.length} className="text-center py-12 text-slate-500">{empty}</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

// ── Loader ─────────────────────────────────────────────────────────────────
export function Loader({ text = 'Loading...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <div className="w-10 h-10 rounded-full border-2 border-blue-500/30 border-t-blue-500 animate-spin" />
      <p className="text-slate-500 text-sm">{text}</p>
    </div>
  );
}

// ── Empty state ────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3 text-center">
      <div className="text-5xl mb-2">{icon}</div>
      <h3 className="font-display font-bold text-xl text-white">{title}</h3>
      <p className="text-slate-500 max-w-sm text-sm">{description}</p>
      {action}
    </div>
  );
}
