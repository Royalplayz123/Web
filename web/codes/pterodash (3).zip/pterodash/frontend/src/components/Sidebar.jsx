import { NavLink, useNavigate } from 'react-router-dom';
import { Server, ShoppingCart, Ticket, Settings, LogOut, LayoutDashboard, Bell, Shield } from 'lucide-react';
import useAuthStore from '../lib/store';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/servers', icon: Server, label: 'Servers' },
  { to: '/store', icon: ShoppingCart, label: 'Store' },
  { to: '/tickets', icon: Ticket, label: 'Tickets' },
];

export default function Sidebar() {
  const { user, unreadNotifications, logout } = useAuthStore();
  const navigate = useNavigate();

  return (
    <aside className="fixed left-0 top-0 h-screen w-56 flex flex-col z-40"
      style={{ background: 'linear-gradient(180deg, #080b14 0%, #0a0f1e 100%)', borderRight: '1px solid rgba(59,130,246,0.1)' }}>

      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-6" style={{ borderBottom: '1px solid rgba(59,130,246,0.08)' }}>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl"
          style={{ background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', boxShadow: '0 0 20px rgba(59,130,246,0.4)' }}>
          🐲
        </div>
        <div>
          <div className="font-display font-black text-white text-[15px] tracking-tight">PteroDash</div>
          <div className="text-[10px] font-semibold tracking-widest uppercase" style={{ color: '#3b82f6' }}>v1.0.0</div>
        </div>
      </div>

      {/* Coins badge */}
      <div className="mx-3 my-4 rounded-xl px-4 py-3 flex items-center gap-3"
        style={{ background: 'linear-gradient(135deg, rgba(59,130,246,0.12), rgba(29,78,216,0.08))', border: '1px solid rgba(59,130,246,0.2)' }}>
        <span className="text-2xl">🪙</span>
        <div>
          <div className="text-[10px] font-semibold uppercase tracking-widest" style={{ color: '#64748b' }}>Balance</div>
          <div className="font-display font-bold text-lg" style={{ color: '#fbbf24' }}>
            {(user?.coins || 0).toLocaleString()}
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 space-y-0.5">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to}
            className={({ isActive }) =>
              `relative flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'nav-active text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
              }`
            }
            style={({ isActive }) => isActive ? {
              background: 'linear-gradient(90deg, rgba(59,130,246,0.18), rgba(59,130,246,0.04))',
            } : {}}>
            <Icon size={16} />
            {label}
          </NavLink>
        ))}

        {/* Admin only */}
        {user?.role === 'admin' && (
          <>
            <div className="pt-3 pb-1 px-4 text-[10px] font-semibold uppercase tracking-widest" style={{ color: '#374151' }}>
              Admin
            </div>
            <NavLink to="/admin"
              className={({ isActive }) =>
                `relative flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive ? 'nav-active text-orange-400' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`
              }
              style={({ isActive }) => isActive ? { background: 'linear-gradient(90deg, rgba(251,146,60,0.15), rgba(251,146,60,0.04))' } : {}}>
              <Shield size={16} />
              Admin Panel
            </NavLink>
          </>
        )}
      </nav>

      {/* Bottom section */}
      <div className="p-3 space-y-1" style={{ borderTop: '1px solid rgba(59,130,246,0.08)' }}>
        <button onClick={() => navigate('/notifications')}
          className="relative w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-all">
          <Bell size={16} />
          Notifications
          {unreadNotifications > 0 && (
            <span className="ml-auto text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: '#ef4444', color: 'white' }}>
              {unreadNotifications}
            </span>
          )}
        </button>
        <button onClick={() => navigate('/settings')}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-all">
          <Settings size={16} />
          Settings
        </button>

        {/* User card */}
        <div className="mt-2 p-3 rounded-xl flex items-center gap-3 cursor-pointer hover:bg-white/5 transition-all"
          style={{ border: '1px solid rgba(255,255,255,0.05)' }} onClick={logout}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
            style={{ background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)' }}>
            {user?.username?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{user?.username}</div>
            <div className="text-xs truncate" style={{ color: '#64748b' }}>{user?.role}</div>
          </div>
          <LogOut size={14} className="text-slate-500 flex-shrink-0" />
        </div>
      </div>
    </aside>
  );
}
