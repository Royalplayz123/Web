import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import api from '../lib/api';
import useAuthStore from '../lib/store';
import { Loader, EmptyState } from '../components/UI';

const CATEGORY_ICONS = {
  ram: '🧠', disk: '💾', cpu: '⚡', servers: '🖥️',
  databases: '🗄️', backups: '📦', allocations: '🌐',
};

const CATEGORY_LABELS = {
  ram: 'Memory', disk: 'Storage', cpu: 'CPU Power',
  servers: 'Server Slots', databases: 'Databases', backups: 'Backups', allocations: 'Allocations',
};

export default function Store() {
  const { user, fetchMe } = useAuthStore();
  const [items, setItems] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [tab, setTab] = useState('store');

  useEffect(() => {
    Promise.all([
      api.get('/store'),
      api.get('/store/transactions'),
    ]).then(([s, t]) => {
      setItems(s.data.items);
      setTransactions(t.data.transactions);
    }).finally(() => setLoading(false));
  }, []);

  const handleBuy = async (item) => {
    if (buying) return;
    setBuying(item.id);
    try {
      const res = await api.post(`/store/buy/${item.id}`);
      toast.success(res.data.message);
      await fetchMe();
      const t = await api.get('/store/transactions');
      setTransactions(t.data.transactions);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Purchase failed');
    } finally { setBuying(null); }
  };

  if (loading) return <Loader text="Loading store..." />;

  const categories = ['all', ...new Set(items.map(i => i.category))];
  const filtered = activeCategory === 'all' ? items : items.filter(i => i.category === activeCategory);

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-black text-3xl text-white">Store</h1>
          <p className="text-slate-500 text-sm mt-1">Spend coins to expand your resources</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl"
          style={{ background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.25)' }}>
          <span className="text-xl">🪙</span>
          <span className="font-display font-bold text-xl" style={{ color: '#fbbf24' }}>
            {(user?.coins || 0).toLocaleString()}
          </span>
          <span className="text-xs text-slate-500">coins</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {['store', 'history'].map(t_ => (
          <button key={t_} onClick={() => setTab(t_)}
            className={`px-5 py-2 rounded-xl text-sm font-semibold transition-all capitalize ${
              tab === t_
                ? 'text-white' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
            style={tab === t_ ? { background: 'rgba(59,130,246,0.2)', border: '1px solid rgba(59,130,246,0.3)' } : {}}>
            {t_ === 'store' ? '🛒 Store' : '📋 History'}
          </button>
        ))}
      </div>

      {tab === 'store' && (
        <>
          {/* Category filters */}
          <div className="flex gap-2 flex-wrap">
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
                  activeCategory === cat ? 'text-blue-400' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                }`}
                style={activeCategory === cat ? { background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' } : {}}>
                {cat === 'all' ? 'All' : `${CATEGORY_ICONS[cat]} ${CATEGORY_LABELS[cat] || cat}`}
              </button>
            ))}
          </div>

          {/* Items grid */}
          {filtered.length === 0 ? (
            <EmptyState icon="🛒" title="No items available" description="The store is currently empty. Check back later!" />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map(item => {
                const canAfford = (user?.coins || 0) >= item.price;
                const isBuying = buying === item.id;
                return (
                  <div key={item.id} className={`glass-card rounded-2xl p-5 transition-all ${canAfford ? 'hover:border-blue-500/30' : 'opacity-60'}`}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                        style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)' }}>
                        {item.icon || CATEGORY_ICONS[item.category] || '📦'}
                      </div>
                      <div className="flex items-center gap-1.5 px-3 py-1 rounded-full"
                        style={{ background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.2)' }}>
                        <span className="text-sm">🪙</span>
                        <span className="font-display font-bold text-base" style={{ color: '#fbbf24' }}>{item.price}</span>
                      </div>
                    </div>
                    <h3 className="font-display font-bold text-white text-base">{item.name}</h3>
                    <p className="text-xs mt-1 mb-4" style={{ color: '#64748b' }}>{item.description}</p>
                    <button
                      onClick={() => handleBuy(item)}
                      disabled={!canAfford || !!buying}
                      className={canAfford ? 'btn-primary w-full' : 'btn-ghost w-full opacity-50 cursor-not-allowed'}
                    >
                      {isBuying ? 'Purchasing...' : canAfford ? 'Purchase' : 'Not enough coins'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {tab === 'history' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          {transactions.length === 0 ? (
            <EmptyState icon="📋" title="No transactions" description="Your purchase history will appear here." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                  {['Description', 'Amount', 'Type', 'Date'].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {transactions.map(t => (
                  <tr key={t.id} className="hover:bg-white/2 transition-all" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                    <td className="px-4 py-3 text-slate-300">{t.description}</td>
                    <td className="px-4 py-3 font-mono font-semibold" style={{ color: t.amount > 0 ? '#4ade80' : '#f87171' }}>
                      {t.amount > 0 ? '+' : ''}{t.amount} 🪙
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs px-2 py-0.5 rounded-full capitalize font-semibold"
                        style={{ background: 'rgba(59,130,246,0.1)', color: '#60a5fa', border: '1px solid rgba(59,130,246,0.2)' }}>
                        {t.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs" style={{ color: '#64748b' }}>
                      {new Date(t.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
