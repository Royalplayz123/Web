import { useEffect, useState } from 'react';
import { Plus, Trash2, RefreshCw, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../lib/api';
import { Badge, Loader, EmptyState, Modal, ResourceBar } from '../components/UI';
import useAuthStore from '../lib/store';

export default function Servers() {
  const { user, resources } = useAuthStore();
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const fetchServers = async () => {
    try {
      const res = await api.get('/servers');
      setServers(res.data.servers);
    } catch { toast.error('Failed to load servers'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchServers(); }, []);

  const handleDelete = async (server) => {
    if (!confirm(`Delete "${server.name}"? This is irreversible.`)) return;
    try {
      await api.delete(`/servers/${server.id}`);
      toast.success('Server deleted');
      fetchServers();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
  };

  const handleReinstall = async (server) => {
    if (!confirm(`Reinstall "${server.name}"? All data will be wiped.`)) return;
    try {
      await api.post(`/servers/${server.id}/reinstall`);
      toast.success('Reinstall triggered');
    } catch {
      toast.error('Reinstall failed');
    }
  };

  if (loading) return <Loader text="Loading servers..." />;

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-black text-3xl text-white">Servers</h1>
          <p className="text-slate-500 text-sm mt-1">{servers.length} / {resources?.servers || 0} slots used</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> New Server
        </button>
      </div>

      {servers.length === 0 ? (
        <EmptyState
          icon="🖥️" title="No servers yet"
          description="Deploy your first game server in seconds. Click the button above to get started."
          action={<button onClick={() => setShowCreate(true)} className="btn-primary">Create Server</button>}
        />
      ) : (
        <div className="grid gap-4">
          {servers.map(server => (
            <ServerCard key={server.id} server={server}
              onDelete={() => handleDelete(server)}
              onReinstall={() => handleReinstall(server)}
            />
          ))}
        </div>
      )}

      {showCreate && (
        <CreateServerModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); fetchServers(); }}
        />
      )}
    </div>
  );
}

function ServerCard({ server, onDelete, onReinstall }) {
  const panelUrl = import.meta.env.VITE_PANEL_URL || '#';
  return (
    <div className="glass-card rounded-2xl p-5 hover:border-blue-500/30 transition-all">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
            style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)' }}>
            🖥️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display font-bold text-lg text-white">{server.name}</h3>
              <Badge status={server.suspended ? 'suspended' : server.status || 'offline'}
                label={server.suspended ? 'Suspended' : server.status} />
            </div>
            <p className="text-sm mt-0.5" style={{ color: '#64748b' }}>
              ID: {server.pterodactyl_uuid?.slice(0, 8)}… · Node {server.node_id}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <a href={`${panelUrl}/server/${server.pterodactyl_uuid}`} target="_blank" rel="noreferrer"
            className="btn-ghost flex items-center gap-1.5 text-xs py-2 px-3">
            <ExternalLink size={13} /> Panel
          </a>
          <button onClick={onReinstall} title="Reinstall"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:text-amber-400 hover:bg-amber-400/10 transition-all">
            <RefreshCw size={15} />
          </button>
          <button onClick={onDelete} title="Delete"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-all">
            <Trash2 size={15} />
          </button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4">
        <ResourceBar label="RAM" used={Math.floor(server.ram * 0.6)} total={server.ram} unit="MB" />
        <ResourceBar label="Disk" used={Math.floor(server.disk * 0.4)} total={server.disk} unit="MB" />
        <ResourceBar label="CPU" used={Math.floor(server.cpu * 0.3)} total={server.cpu} unit="%" />
      </div>

      <div className="mt-3 flex gap-4 text-xs" style={{ color: '#64748b' }}>
        <span>💾 {server.databases} DB{server.databases !== 1 ? 's' : ''}</span>
        <span>📦 {server.backups} Backup{server.backups !== 1 ? 's' : ''}</span>
        <span>🌐 {server.allocations} Port{server.allocations !== 1 ? 's' : ''}</span>
      </div>
    </div>
  );
}

function CreateServerModal({ onClose, onCreated }) {
  const [step, setStep] = useState(1);
  const [options, setOptions] = useState({ nodes: [], nests: [], locations: [] });
  const [eggs, setEggs] = useState([]);
  const [form, setForm] = useState({
    name: '', description: '', nodeId: '', nestId: '', eggId: '',
    ram: 512, disk: 2048, cpu: 100, databases: 0, backups: 0,
  });
  const [loading, setLoading] = useState(false);
  const [optLoading, setOptLoading] = useState(true);

  useEffect(() => {
    api.get('/servers/options').then(r => {
      setOptions(r.data);
    }).catch(() => toast.error('Failed to load panel options'))
    .finally(() => setOptLoading(false));
  }, []);

  useEffect(() => {
    if (form.nestId) {
      api.get(`/servers/eggs/${form.nestId}`).then(r => setEggs(r.data.eggs));
    }
  }, [form.nestId]);

  const handleSubmit = async () => {
    if (!form.name || !form.nodeId || !form.nestId || !form.eggId) {
      return toast.error('Please fill all required fields');
    }
    setLoading(true);
    try {
      await api.post('/servers', form);
      toast.success('Server created! Installing now...');
      onCreated();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create server');
    } finally { setLoading(false); }
  };

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Modal title={`Create Server — Step ${step}/3`} onClose={onClose} width={580}>
      {optLoading ? <Loader text="Loading panel options..." /> : (
        <>
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Server Name *</label>
                <input className="dash-input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="My Minecraft Server" />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Description</label>
                <input className="dash-input" value={form.description} onChange={e => set('description', e.target.value)} placeholder="Optional description" />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Node *</label>
                <select className="dash-input" value={form.nodeId} onChange={e => set('nodeId', e.target.value)}>
                  <option value="">Select a node...</option>
                  {options.nodes.map(n => <option key={n.id} value={n.id}>{n.name} — {n.location_id}</option>)}
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Nest (Game Type) *</label>
                <select className="dash-input" value={form.nestId} onChange={e => { set('nestId', e.target.value); set('eggId', ''); }}>
                  <option value="">Select nest...</option>
                  {options.nests.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                </select>
              </div>
              {form.nestId && (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Egg (Version) *</label>
                  <select className="dash-input" value={form.eggId} onChange={e => set('eggId', e.target.value)}>
                    <option value="">Select egg...</option>
                    {eggs.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              {[
                { key: 'ram', label: 'RAM (MB)', min: 128, max: 32768, step: 128 },
                { key: 'disk', label: 'Disk (MB)', min: 512, max: 102400, step: 512 },
                { key: 'cpu', label: 'CPU (%)', min: 10, max: 800, step: 10 },
                { key: 'databases', label: 'Databases', min: 0, max: 10, step: 1 },
                { key: 'backups', label: 'Backups', min: 0, max: 10, step: 1 },
              ].map(({ key, label, min, max, step: s }) => (
                <div key={key}>
                  <div className="flex justify-between mb-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{label}</label>
                    <span className="text-xs font-mono font-semibold text-blue-400">{form[key]}</span>
                  </div>
                  <input type="range" min={min} max={max} step={s} value={form[key]}
                    onChange={e => set(key, parseInt(e.target.value))}
                    className="w-full accent-blue-500" />
                </div>
              ))}

              {/* Summary */}
              <div className="mt-4 p-4 rounded-xl space-y-1" style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)' }}>
                <div className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#64748b' }}>Summary</div>
                <div className="text-sm text-slate-300"><strong className="text-white">{form.name}</strong> on Node {form.nodeId}</div>
                <div className="text-xs text-slate-500">{form.ram}MB RAM · {form.disk}MB Disk · {form.cpu}% CPU</div>
              </div>
            </div>
          )}

          <div className="flex gap-3 mt-6">
            {step > 1 && <button onClick={() => setStep(s => s - 1)} className="btn-ghost flex-1">Back</button>}
            {step < 3
              ? <button onClick={() => setStep(s => s + 1)} className="btn-primary flex-1">Next →</button>
              : <button onClick={handleSubmit} disabled={loading} className="btn-primary flex-1">
                  {loading ? 'Creating...' : 'Create Server 🚀'}
                </button>
            }
          </div>
        </>
      )}
    </Modal>
  );
}
