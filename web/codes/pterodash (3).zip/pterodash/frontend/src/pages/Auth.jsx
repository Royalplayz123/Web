import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import useAuthStore from '../lib/store';

function AuthLayout({ children, title, subtitle }) {
  return (
    <div className="min-h-screen bg-grid flex items-center justify-center p-4"
      style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(59,130,246,0.08) 0%, #060810 60%)' }}>
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4"
            style={{ background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', boxShadow: '0 0 40px rgba(59,130,246,0.4)' }}>
            🐲
          </div>
          <h1 className="font-display font-black text-3xl text-white tracking-tight">{title}</h1>
          <p className="text-slate-500 mt-1 text-sm">{subtitle}</p>
        </div>

        <div className="glass-card rounded-2xl p-8 glow-blue">
          {children}
        </div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Welcome back" subtitle="Sign in to PteroDash">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>
            Email
          </label>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)}
            className="dash-input" placeholder="you@example.com" required />
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>
            Password
          </label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            className="dash-input" placeholder="••••••••" required />
        </div>
        <button type="submit" disabled={loading} className="btn-primary w-full py-3 mt-2">
          {loading ? 'Signing in...' : 'Sign In'}
        </button>
      </form>
      <p className="text-center text-sm text-slate-500 mt-6">
        No account?{' '}
        <Link to="/register" className="text-blue-400 font-semibold hover:text-blue-300 transition-colors">
          Register
        </Link>
      </p>
    </AuthLayout>
  );
}

export function RegisterPage() {
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      toast.success('Account created! Welcome 🎉');
      navigate('/dashboard');
    } catch (err) {
      const errs = err.response?.data?.errors;
      toast.error(errs?.[0]?.msg || err.response?.data?.error || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Create account" subtitle="Join PteroDash today">
      <form onSubmit={handleSubmit} className="space-y-4">
        {[
          { key: 'username', label: 'Username', type: 'text', placeholder: 'cooluser123' },
          { key: 'email', label: 'Email', type: 'email', placeholder: 'you@example.com' },
          { key: 'password', label: 'Password', type: 'password', placeholder: '••••••••' },
        ].map(({ key, label, type, placeholder }) => (
          <div key={key}>
            <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>
              {label}
            </label>
            <input type={type} value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}
              className="dash-input" placeholder={placeholder} required />
          </div>
        ))}
        <button type="submit" disabled={loading} className="btn-primary w-full py-3 mt-2">
          {loading ? 'Creating account...' : 'Create Account'}
        </button>
      </form>
      <p className="text-center text-sm text-slate-500 mt-6">
        Have an account?{' '}
        <Link to="/login" className="text-blue-400 font-semibold hover:text-blue-300 transition-colors">
          Sign in
        </Link>
      </p>
    </AuthLayout>
  );
}
