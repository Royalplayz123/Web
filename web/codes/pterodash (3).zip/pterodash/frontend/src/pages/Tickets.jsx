import { useEffect, useState } from 'react';
import { Send, Plus, ChevronLeft } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../lib/api';
import useAuthStore from '../lib/store';
import { Badge, Loader, EmptyState, Modal } from '../components/UI';

export default function Tickets() {
  const { user } = useAuthStore();
  const [tickets, setTickets] = useState([]);
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [reply, setReply] = useState('');
  const [loading, setLoading] = useState(true);
  const [msgLoading, setMsgLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [showCreate, setShowCreate] = useState(false);

  const fetchTickets = async () => {
    try {
      const res = await api.get('/tickets');
      setTickets(res.data.tickets);
    } catch { toast.error('Failed to load tickets'); }
    finally { setLoading(false); }
  };

  const openTicket = async (ticket) => {
    setSelected(ticket);
    setMsgLoading(true);
    try {
      const res = await api.get(`/tickets/${ticket.id}`);
      setMessages(res.data.messages);
    } catch { toast.error('Failed to load messages'); }
    finally { setMsgLoading(false); }
  };

  const handleReply = async () => {
    if (!reply.trim()) return;
    setSending(true);
    try {
      await api.post(`/tickets/${selected.id}/reply`, { message: reply });
      setReply('');
      await openTicket(selected);
      fetchTickets();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to send reply');
    } finally { setSending(false); }
  };

  const handleClose = async () => {
    if (!confirm('Close this ticket?')) return;
    try {
      await api.patch(`/tickets/${selected.id}/close`);
      toast.success('Ticket closed');
      setSelected(null);
      fetchTickets();
    } catch { toast.error('Failed to close ticket'); }
  };

  useEffect(() => { fetchTickets(); }, []);

  if (loading) return <Loader text="Loading tickets..." />;

  // Ticket detail view
  if (selected) {
    return (
      <div className="page-enter flex flex-col h-full" style={{ maxHeight: 'calc(100vh - 80px)' }}>
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setSelected(null)} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm font-medium">
            <ChevronLeft size={16} /> Back to tickets
          </button>
          {selected.status !== 'closed' && (
            <button onClick={handleClose} className="btn-ghost text-xs py-1.5 px-3 text-red-400 border-red-400/20 hover:bg-red-400/10">
              Close Ticket
            </button>
          )}
        </div>

        <div className="glass-card rounded-2xl flex flex-col flex-1 overflow-hidden">
          {/* Ticket header */}
          <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
            <div>
              <h2 className="font-display font-bold text-white">{selected.subject}</h2>
              <div className="flex items-center gap-2 mt-1">
                <Badge status={selected.priority} label={selected.priority} />
                <Badge status={selected.status} label={selected.status.replace('_', ' ')} />
                <span className="text-xs" style={{ color: '#64748b' }}>#{selected.id} · {selected.category}</span>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {msgLoading ? <Loader /> : messages.map(msg => {
              const isMe = msg.user_id === user?.id;
              const isAdmin = msg.is_admin_reply;
              return (
                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                  <div style={{ maxWidth: '70%' }}>
                    <div className="flex items-center gap-2 mb-1" style={{ justifyContent: isMe ? 'flex-end' : 'flex-start' }}>
                      {isAdmin && <span className="text-xs px-1.5 py-0.5 rounded font-semibold" style={{ background: 'rgba(251,146,60,0.15)', color: '#fb923c' }}>Staff</span>}
                      <span className="text-xs font-semibold" style={{ color: '#64748b' }}>{msg.username}</span>
                    </div>
                    <div className={`rounded-2xl px-4 py-3 text-sm ${isMe ? 'rounded-tr-sm' : 'rounded-tl-sm'}`}
                      style={{
                        background: isMe ? 'linear-gradient(135deg, #3b82f6, #1d4ed8)' : 'rgba(255,255,255,0.06)',
                        border: isMe ? 'none' : '1px solid rgba(255,255,255,0.06)',
                        color: isMe ? 'white' : '#e2e8f0',
                      }}>
                      {msg.message}
                    </div>
                    <div className="text-xs mt-1" style={{ color: '#374151', textAlign: isMe ? 'right' : 'left' }}>
                      {new Date(msg.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Reply box */}
          {selected.status !== 'closed' ? (
            <div className="p-4 flex gap-3" style={{ borderTop: '1px solid rgba(59,130,246,0.1)' }}>
              <input
                className="dash-input flex-1"
                placeholder="Type your reply..."
                value={reply}
                onChange={e => setReply(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleReply()}
              />
              <button onClick={handleReply} disabled={sending || !reply.trim()} className="btn-primary flex items-center gap-2 px-4">
                <Send size={15} />
                {sending ? '...' : 'Send'}
              </button>
            </div>
          ) : (
            <div className="p-4 text-center text-sm" style={{ borderTop: '1px solid rgba(59,130,246,0.1)', color: '#64748b' }}>
              This ticket is closed. Open a new one if you need more help.
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-black text-3xl text-white">Support Tickets</h1>
          <p className="text-slate-500 text-sm mt-1">{tickets.filter(t => t.status !== 'closed').length} open tickets</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> New Ticket
        </button>
      </div>

      {tickets.length === 0 ? (
        <EmptyState icon="🎫" title="No tickets" description="Need help? Open a support ticket and our team will get back to you."
          action={<button onClick={() => setShowCreate(true)} className="btn-primary">Open Ticket</button>}
        />
      ) : (
        <div className="glass-card rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                {['#', 'Subject', 'Category', 'Priority', 'Status', 'Updated', ''].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tickets.map(t => (
                <tr key={t.id} className="hover:bg-white/3 cursor-pointer transition-all" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}
                  onClick={() => openTicket(t)}>
                  <td className="px-4 py-3 text-slate-500 font-mono text-xs">#{t.id}</td>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-white">{t.subject}</div>
                    <div className="text-xs text-slate-500">{t.message_count} message{t.message_count !== 1 ? 's' : ''}</div>
                  </td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{t.category}</td>
                  <td className="px-4 py-3"><Badge status={t.priority} /></td>
                  <td className="px-4 py-3"><Badge status={t.status} label={t.status.replace('_', ' ')} /></td>
                  <td className="px-4 py-3 text-xs text-slate-500">{new Date(t.updated_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-blue-400 text-xs font-semibold">View →</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showCreate && <CreateTicketModal onClose={() => setShowCreate(false)} onCreated={() => { setShowCreate(false); fetchTickets(); }} />}
    </div>
  );
}

function CreateTicketModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ subject: '', message: '', priority: 'medium', category: 'General' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!form.subject || !form.message) return toast.error('Please fill all fields');
    setLoading(true);
    try {
      await api.post('/tickets', form);
      toast.success('Ticket opened!');
      onCreated();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create ticket');
    } finally { setLoading(false); }
  };

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Modal title="Open Support Ticket" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Subject *</label>
          <input className="dash-input" value={form.subject} onChange={e => set('subject', e.target.value)} placeholder="Brief description of your issue" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Category</label>
            <select className="dash-input" value={form.category} onChange={e => set('category', e.target.value)}>
              {['General', 'Billing', 'Technical', 'Abuse', 'Other'].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Priority</label>
            <select className="dash-input" value={form.priority} onChange={e => set('priority', e.target.value)}>
              {['low', 'medium', 'high', 'critical'].map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Message *</label>
          <textarea className="dash-input" rows={5} value={form.message} onChange={e => set('message', e.target.value)}
            placeholder="Describe your issue in detail..." style={{ resize: 'vertical' }} />
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary flex-1">
            {loading ? 'Opening...' : 'Open Ticket 🎫'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
