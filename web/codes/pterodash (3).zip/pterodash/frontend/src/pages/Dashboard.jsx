import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Server, Ticket, Coins, TrendingUp } from 'lucide-react';
import api from '../lib/api';
import useAuthStore from '../lib/store';
import { StatCard, ResourceBar, Badge, Loader } from '../components/UI';

const CHART_DATA = [
  { day: 'Mon', coins: 420 }, { day: 'Tue', coins: 580 }, { day: 'Wed', coins: 510 },
  { day: 'Thu', coins: 720 }, { day: 'Fri', coins: 660 }, { day: 'Sat', coins: 890 },
  { day: 'Sun', coins: 950 },
];

export default function Dashboard() {
  const { user, resources } = useAuthStore();
  const [servers, setServers] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get('/servers').catch(() => ({ data: { servers: [] } })),
      api.get('/tickets').catch(() => ({ data: { tickets: [] } })),
      api.get('/notifications').catch(() => ({ data: { notifications: [] } })),
    ]).then(([srv, tkt, notif]) => {
      setServers(srv.data.servers.slice(0, 4));
      setTickets(tkt.data.tickets.slice(0, 3));
      setNotifications(notif.data.notifications.slice(0, 5));
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader text="Loading dashboard..." />;

  const openTickets = tickets.filter(t => t.status !== 'closed').length;

  return (
    <div className="page-enter space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-white">
          Welcome back, <span style={{ color: '#60a5fa' }}>{user?.username}</span> 👋
        </h1>
        <p className="text-slate-500 mt-1 text-sm">Here's your server empire at a glance.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard icon="🖥️" label="Servers" value={servers.length} sub={`of ${resources?.servers || 0} slots`} color="#3b82f6" />
        <StatCard icon="🪙" label="Coins" value={(user?.coins || 0).toLocaleString()} sub="Available balance" color="#fbbf24" />
        <StatCard icon="🎫" label="Open Tickets" value={openTickets} sub="Support requests" color="#8b5cf6" />
        <StatCard icon="⚡" label="CPU Budget" value={`${resources?.cpu || 0}%`} sub="Available cores" color="#22c55e" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Resources */}
        <div className="glass-card rounded-2xl p-6">
          <h2 className="font-display font-bold text-base text-white mb-5">Resource Pool</h2>
          <div className="space-y-5">
            <ResourceBar label="RAM" used={resources?.ram || 0} total={(resources?.ram || 0) + 2048} unit="MB" />
            <ResourceBar label="Disk" used={resources?.disk || 0} total={(resources?.disk || 0) + 10240} unit="MB" />
            <ResourceBar label="CPU" used={resources?.cpu || 0} total={(resources?.cpu || 0) + 200} unit="%" />
          </div>
          <div className="mt-5 pt-4 grid grid-cols-3 gap-3" style={{ borderTop: '1px solid rgba(59,130,246,0.1)' }}>
            {[
              { label: 'Servers', val: resources?.servers },
              { label: 'DBs', val: resources?.databases },
              { label: 'Backups', val: resources?.backups },
            ].map(({ label, val }) => (
              <div key={label} className="text-center">
                <div className="font-display font-black text-xl text-white">{val || 0}</div>
                <div className="text-xs mt-0.5" style={{ color: '#64748b' }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Coin chart */}
        <div className="glass-card rounded-2xl p-6 xl:col-span-2">
          <h2 className="font-display font-bold text-base text-white mb-5">Coin History (this week)</h2>
          <ResponsiveContainer width="100%" height={150}>
            <AreaChart data={CHART_DATA}>
              <defs>
                <linearGradient id="coinGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: '#0d1220', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 8, color: '#f1f5f9', fontSize: 12 }} />
              <Area type="monotone" dataKey="coins" stroke="#3b82f6" strokeWidth={2} fill="url(#coinGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Recent servers */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-base text-white">Your Servers</h2>
            <button onClick={() => navigate('/servers')} className="text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors">
              View all →
            </button>
          </div>
          {servers.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-sm">No servers yet</div>
          ) : (
            <div className="space-y-2">
              {servers.map(s => (
                <div key={s.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all cursor-pointer"
                  onClick={() => navigate('/servers')}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base"
                    style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.15)' }}>
                    🖥️
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-white truncate">{s.name}</div>
                    <div className="text-xs truncate" style={{ color: '#64748b' }}>{s.ram}MB RAM · {s.disk}MB Disk</div>
                  </div>
                  <Badge status={s.suspended ? 'suspended' : s.status || 'offline'} label={s.suspended ? 'Suspended' : s.status} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-base text-white">Recent Notifications</h2>
            <button onClick={() => navigate('/notifications')} className="text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors">
              View all →
            </button>
          </div>
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-sm">No notifications</div>
          ) : (
            <div className="space-y-2">
              {notifications.map(n => {
                const colors = { success: '#22c55e', info: '#3b82f6', warning: '#f59e0b', error: '#ef4444' };
                const c = colors[n.type] || colors.info;
                return (
                  <div key={n.id} className="flex gap-3 p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="w-1.5 rounded-full flex-shrink-0 mt-1" style={{ background: c, minHeight: 12 }} />
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-white">{n.title}</div>
                      <div className="text-xs mt-0.5 truncate" style={{ color: '#64748b' }}>{n.message}</div>
                    </div>
                    {!n.is_read && <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5" style={{ background: '#3b82f6' }} />}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
