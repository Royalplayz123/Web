import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import api from '../lib/api';
import { Badge, StatCard, Loader, Modal } from '../components/UI';

export default function Admin() {
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [servers, setServers] = useState([]);
  const [storeItems, setStoreItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editUser, setEditUser] = useState(null);
  const [grantModal, setGrantModal] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [st, u, srv, store] = await Promise.all([
        api.get('/admin/stats'),
        api.get('/admin/users'),
        api.get('/admin/servers'),
        api.get('/admin/store'),
      ]);
      setStats(st.data);
      setUsers(u.data.users);
      setServers(srv.data.servers);
      setStoreItems(store.data.items);
    } catch { toast.error('Failed to load admin data'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleBanToggle = async (u) => {
    const action = u.is_banned ? 'unban' : 'ban';
    if (!confirm(`${action.charAt(0).toUpperCase() + action.slice(1)} user "${u.username}"?`)) return;
    try {
      await api.patch(`/admin/users/${u.id}`, { is_banned: !u.is_banned, ban_reason: u.is_banned ? null : 'Banned by admin' });
      toast.success(`User ${action}ned`);
      fetchData();
    } catch { toast.error('Action failed'); }
  };

  const handleSuspendServer = async (srv, suspend) => {
    try {
      await api.post(`/admin/servers/${srv.id}/${suspend ? 'suspend' : 'unsuspend'}`);
      toast.success(`Server ${suspend ? 'suspended' : 'unsuspended'}`);
      fetchData();
    } catch { toast.error('Action failed'); }
  };

  if (loading) return <Loader text="Loading admin panel..." />;

  const TABS = ['overview', 'users', 'servers', 'store'];

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
          style={{ background: 'rgba(251,146,60,0.15)', border: '1px solid rgba(251,146,60,0.3)' }}>⚙️</div>
        <div>
          <h1 className="font-display font-black text-3xl text-white">Admin Panel</h1>
          <p className="text-slate-500 text-sm mt-0.5">Manage everything from one place</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', width: 'fit-content' }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${
              tab === t ? 'text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
            style={tab === t ? { background: 'rgba(59,130,246,0.25)', border: '1px solid rgba(59,130,246,0.4)' } : {}}>
            {t}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && stats && (
        <>
          <div className="grid grid-cols-2 xl:grid-cols-5 gap-4">
            <StatCard icon="👥" label="Total Users" value={stats.stats.totalUsers} color="#3b82f6" />
            <StatCard icon="🖥️" label="Servers" value={stats.stats.totalServers} color="#8b5cf6" />
            <StatCard icon="🎫" label="Open Tickets" value={stats.stats.openTickets} color="#f59e0b" />
            <StatCard icon="🪙" label="Total Coins" value={(stats.stats.totalCoins || 0).toLocaleString()} color="#fbbf24" />
            <StatCard icon="🚫" label="Banned Users" value={stats.stats.bannedUsers} color="#ef4444" />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div className="glass-card rounded-2xl p-5">
              <h2 className="font-display font-bold text-base text-white mb-4">Recent Users</h2>
              <div className="space-y-2">
                {stats.recentUsers.map(u => (
                  <div key={u.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                      style={{ background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)' }}>
                      {u.username[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-white">{u.username}</div>
                      <div className="text-xs truncate" style={{ color: '#64748b' }}>{u.email}</div>
                    </div>
                    <Badge status={u.role} label={u.role} />
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-card rounded-2xl p-5">
              <h2 className="font-display font-bold text-base text-white mb-4">Recent Tickets</h2>
              <div className="space-y-2">
                {stats.recentTickets.map(t => (
                  <div key={t.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-white truncate">{t.subject}</div>
                      <div className="text-xs" style={{ color: '#64748b' }}>by {t.username}</div>
                    </div>
                    <Badge status={t.status} label={t.status.replace('_', ' ')} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Users */}
      {tab === 'users' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-4" style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
            <input className="dash-input max-w-sm" placeholder="Search users..." value={search}
              onChange={e => setSearch(e.target.value)} />
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                {['User', 'Email', 'Role', 'Coins', 'Servers', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.filter(u => !search || u.username.includes(search) || u.email.includes(search)).map(u => (
                <tr key={u.id} className="hover:bg-white/2 transition-all" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)' }}>
                        {u.username[0].toUpperCase()}
                      </div>
                      <span className="font-semibold text-white">{u.username}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{u.email}</td>
                  <td className="px-4 py-3"><Badge status={u.role} /></td>
                  <td className="px-4 py-3 font-mono text-yellow-400">{u.coins}</td>
                  <td className="px-4 py-3 text-slate-400">{u.server_count}</td>
                  <td className="px-4 py-3"><Badge status={u.is_banned ? 'banned' : 'active'} label={u.is_banned ? 'Banned' : 'Active'} /></td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => setGrantModal(u)}
                        className="text-xs px-2 py-1 rounded-lg font-semibold transition-all text-yellow-400 hover:bg-yellow-400/10">
                        Coins
                      </button>
                      <button onClick={() => handleBanToggle(u)}
                        className={`text-xs px-2 py-1 rounded-lg font-semibold transition-all ${u.is_banned ? 'text-green-400 hover:bg-green-400/10' : 'text-red-400 hover:bg-red-400/10'}`}>
                        {u.is_banned ? 'Unban' : 'Ban'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Servers */}
      {tab === 'servers' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                {['Name', 'Owner', 'Resources', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {servers.map(srv => (
                <tr key={srv.id} className="hover:bg-white/2 transition-all" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td className="px-4 py-3 font-semibold text-white">{srv.name}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{srv.owner_name}</td>
                  <td className="px-4 py-3 text-xs text-slate-400">{srv.ram}MB · {srv.disk}MB · {srv.cpu}%</td>
                  <td className="px-4 py-3"><Badge status={srv.suspended ? 'suspended' : srv.status || 'offline'} label={srv.suspended ? 'Suspended' : srv.status} /></td>
                  <td className="px-4 py-3">
                    <button onClick={() => handleSuspendServer(srv, !srv.suspended)}
                      className={`text-xs px-2 py-1 rounded-lg font-semibold transition-all ${srv.suspended ? 'text-green-400 hover:bg-green-400/10' : 'text-red-400 hover:bg-red-400/10'}`}>
                      {srv.suspended ? 'Unsuspend' : 'Suspend'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Store */}
      {tab === 'store' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                {['Name', 'Category', 'Amount', 'Price', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {storeItems.map(item => (
                <tr key={item.id} className="hover:bg-white/2 transition-all" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td className="px-4 py-3 text-white font-semibold">{item.icon} {item.name}</td>
                  <td className="px-4 py-3 text-slate-400 capitalize">{item.category}</td>
                  <td className="px-4 py-3 font-mono text-slate-300">{item.amount}</td>
                  <td className="px-4 py-3 font-mono text-yellow-400">🪙 {item.price}</td>
                  <td className="px-4 py-3">
                    <Badge status={item.is_active ? 'active' : 'offline'} label={item.is_active ? 'Active' : 'Hidden'} />
                  </td>
                  <td className="px-4 py-3">
                    <button onClick={async () => {
                      await api.patch(`/admin/store/${item.id}`, { is_active: !item.is_active });
                      fetchData();
                    }} className="text-xs px-2 py-1 rounded-lg font-semibold text-blue-400 hover:bg-blue-400/10 transition-all">
                      {item.is_active ? 'Hide' : 'Show'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Grant Coins Modal */}
      {grantModal && (
        <GrantCoinsModal user={grantModal} onClose={() => setGrantModal(null)} onDone={() => { setGrantModal(null); fetchData(); }} />
      )}
    </div>
  );
}

function GrantCoinsModal({ user, onClose, onDone }) {
  const [amount, setAmount] = useState(0);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!amount) return toast.error('Enter an amount');
    setLoading(true);
    try {
      await api.post(`/admin/users/${user.id}/grant-coins`, { amount: parseInt(amount), reason });
      toast.success(`${amount > 0 ? 'Granted' : 'Deducted'} ${Math.abs(amount)} coins`);
      onDone();
    } catch { toast.error('Action failed'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title={`Manage Coins — ${user.username}`} onClose={onClose}>
      <div className="space-y-4">
        <div className="p-3 rounded-xl text-center" style={{ background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.2)' }}>
          <div className="text-xs text-slate-500">Current balance</div>
          <div className="font-display font-black text-2xl text-yellow-400">🪙 {user.coins}</div>
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>
            Amount (use negative to deduct)
          </label>
          <input type="number" className="dash-input" value={amount} onChange={e => setAmount(e.target.value)} placeholder="e.g. 500 or -100" />
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>Reason</label>
          <input className="dash-input" value={reason} onChange={e => setReason(e.target.value)} placeholder="Optional reason..." />
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary flex-1">
            {loading ? '...' : 'Apply'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
