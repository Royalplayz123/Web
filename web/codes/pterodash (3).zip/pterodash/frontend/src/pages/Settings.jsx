import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import api from '../lib/api';
import useAuthStore from '../lib/store';
import { Loader, EmptyState } from '../components/UI';

export function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const { fetchMe } = useAuthStore();

  useEffect(() => {
    api.get('/notifications').then(r => setNotifications(r.data.notifications)).finally(() => setLoading(false));
  }, []);

  const markAllRead = async () => {
    await api.patch('/notifications/read-all');
    setNotifications(n => n.map(x => ({ ...x, is_read: 1 })));
    fetchMe();
    toast.success('All notifications marked as read');
  };

  if (loading) return <Loader />;

  const typeColors = { success: '#22c55e', info: '#3b82f6', warning: '#f59e0b', error: '#ef4444' };

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-black text-3xl text-white">Notifications</h1>
          <p className="text-slate-500 text-sm mt-1">{notifications.filter(n => !n.is_read).length} unread</p>
        </div>
        <button onClick={markAllRead} className="btn-ghost text-sm">Mark all read</button>
      </div>

      {notifications.length === 0 ? (
        <EmptyState icon="🔔" title="No notifications" description="You're all caught up!" />
      ) : (
        <div className="space-y-2">
          {notifications.map(n => {
            const c = typeColors[n.type] || typeColors.info;
            return (
              <div key={n.id} className={`glass-card rounded-xl p-4 flex gap-4 transition-all ${!n.is_read ? '' : 'opacity-60'}`}>
                <div className="w-1 rounded-full flex-shrink-0" style={{ background: c }} />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-white text-sm">{n.title}</h3>
                    <span className="text-xs" style={{ color: '#64748b' }}>{new Date(n.created_at).toLocaleDateString()}</span>
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: '#94a3b8' }}>{n.message}</p>
                </div>
                {!n.is_read && <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5" style={{ background: '#3b82f6' }} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function SettingsPage() {
  const { user } = useAuthStore();
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [loading, setLoading] = useState(false);

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (passwords.newPassword !== passwords.confirm) return toast.error('Passwords do not match');
    if (passwords.newPassword.length < 8) return toast.error('Password must be at least 8 characters');
    setLoading(true);
    try {
      await api.post('/auth/change-password', { currentPassword: passwords.currentPassword, newPassword: passwords.newPassword });
      toast.success('Password changed successfully!');
      setPasswords({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to change password');
    } finally { setLoading(false); }
  };

  return (
    <div className="page-enter space-y-6 max-w-2xl">
      <div>
        <h1 className="font-display font-black text-3xl text-white">Settings</h1>
        <p className="text-slate-500 text-sm mt-1">Manage your account settings</p>
      </div>

      {/* Profile info */}
      <div className="glass-card rounded-2xl p-6">
        <h2 className="font-display font-bold text-base text-white mb-4">Account Info</h2>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black"
            style={{ background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)' }}>
            {user?.username?.[0]?.toUpperCase()}
          </div>
          <div>
            <div className="font-display font-bold text-xl text-white">{user?.username}</div>
            <div className="text-slate-400 text-sm">{user?.email}</div>
            <div className="mt-1 text-xs px-2 py-0.5 rounded-full w-fit capitalize font-semibold"
              style={{ background: 'rgba(251,146,60,0.12)', color: '#fb923c', border: '1px solid rgba(251,146,60,0.2)' }}>
              {user?.role}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-4" style={{ borderTop: '1px solid rgba(59,130,246,0.1)' }}>
          <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
            <div className="text-xs text-slate-500 mb-1">User ID</div>
            <div className="font-mono text-sm text-slate-300">#{user?.id}</div>
          </div>
          <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
            <div className="text-xs text-slate-500 mb-1">Coins</div>
            <div className="font-display font-bold text-yellow-400">🪙 {(user?.coins || 0).toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Change password */}
      <div className="glass-card rounded-2xl p-6">
        <h2 className="font-display font-bold text-base text-white mb-4">Change Password</h2>
        <form onSubmit={handlePasswordChange} className="space-y-4">
          {[
            { key: 'currentPassword', label: 'Current Password', placeholder: '••••••••' },
            { key: 'newPassword', label: 'New Password', placeholder: '••••••••' },
            { key: 'confirm', label: 'Confirm New Password', placeholder: '••••••••' },
          ].map(({ key, label, placeholder }) => (
            <div key={key}>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#64748b' }}>{label}</label>
              <input type="password" className="dash-input" placeholder={placeholder}
                value={passwords[key]} onChange={e => setPasswords(p => ({ ...p, [key]: e.target.value }))} />
            </div>
          ))}
          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? 'Saving...' : 'Change Password'}
          </button>
        </form>
      </div>

      {/* Panel link */}
      <div className="glass-card rounded-2xl p-6">
        <h2 className="font-display font-bold text-base text-white mb-2">Pterodactyl Panel</h2>
        <p className="text-slate-500 text-sm mb-4">Access your Pterodactyl panel to manage servers directly.</p>
        <a href={import.meta.env.VITE_PANEL_URL || '#'} target="_blank" rel="noreferrer" className="btn-ghost inline-flex items-center gap-2 text-sm">
          🔗 Open Panel
        </a>
      </div>
    </div>
  );
}
