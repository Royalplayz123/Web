# 🐲 PteroDash

A full-stack Pterodactyl client dashboard built with **React + Node.js + MySQL**.

## ✨ Features

- 🔐 **Auth** — Register/Login with JWT, auto-ban suspension
- 🖥️ **Server Management** — Create, delete, reinstall servers via Pterodactyl API  
- 🛒 **Coin Store** — Buy RAM, Disk, CPU, Server Slots, DBs, Backups with coins
- 🎫 **Support Tickets** — Full ticket system with admin replies
- 🔔 **Notifications** — Per-user notification center
- ⚙️ **Admin Panel** — Manage users, servers, coins, store items
- 📊 **Dashboard** — Stats, resource gauges, coin history chart

---

## 🚀 Quick Start (Docker — Recommended)

### 1. Clone & configure
```bash
git clone https://github.com/your-org/pterodash
cd pterodash

# Copy and edit environment files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

### 2. Edit `docker/docker-compose.yml`
Fill in:
- `PTERODACTYL_URL` — Your panel URL (e.g. `https://panel.yourdomain.com`)
- `PTERODACTYL_API_KEY` — Application API key from your panel (Admin → Application API)
- `JWT_SECRET` — A long random string (generate with `openssl rand -hex 32`)
- `DB_PASSWORD` & `MYSQL_PASSWORD` — Same password, change from default
- `VITE_PANEL_URL` — Same as PTERODACTYL_URL

### 3. Launch
```bash
cd docker
docker-compose up -d
```

Visit `http://your-server-ip` — the first user to register becomes **admin**.

---

## 🛠️ Manual Setup

### Requirements
- Node.js 20+
- MySQL 8.0+
- A running Pterodactyl Panel

### Database
```bash
mysql -u root -p < backend/src/db/schema.sql
```

### Backend
```bash
cd backend
cp .env.example .env
# Edit .env with your values
npm install
npm start
```

### Frontend
```bash
cd frontend
cp .env.example .env
# Edit .env with your panel URL
npm install
npm run dev   # development
npm run build # production
```

---

## 🔑 Getting Your Pterodactyl API Key

1. Log in to your Pterodactyl Panel as admin
2. Go to **Admin → Application API**
3. Create a new key with **Read & Write** permissions
4. Copy the key — it starts with `ptla_`

---

## 📁 Project Structure

```
pterodash/
├── backend/
│   ├── src/
│   │   ├── db/           # MySQL pool & schema
│   │   ├── middleware/   # JWT auth guard
│   │   ├── routes/       # auth, servers, store, tickets, admin, notifications
│   │   ├── services/     # Pterodactyl API wrapper
│   │   └── index.js      # Express entry point
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/   # Sidebar, UI components
│   │   ├── lib/          # API client, Zustand store
│   │   ├── pages/        # Dashboard, Servers, Store, Tickets, Admin, Auth
│   │   └── App.jsx       # Router + auth guards
│   ├── Dockerfile
│   └── nginx.conf
└── docker/
    └── docker-compose.yml
```

---

## 🔐 Default Admin Login

After running the schema, a default admin is seeded:
- **Email:** `admin@pterodash.local`  
- **Password:** `Admin@1234`

⚠️ **Change this immediately after first login!**

---

## 🌐 API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/register` | — | Register user |
| POST | `/api/auth/login` | — | Login |
| GET | `/api/auth/me` | ✅ | Current user |
| GET | `/api/servers` | ✅ | List servers |
| POST | `/api/servers` | ✅ | Create server |
| DELETE | `/api/servers/:id` | ✅ | Delete server |
| GET | `/api/store` | ✅ | List store items |
| POST | `/api/store/buy/:id` | ✅ | Purchase item |
| GET | `/api/tickets` | ✅ | List tickets |
| POST | `/api/tickets` | ✅ | Open ticket |
| POST | `/api/tickets/:id/reply` | ✅ | Reply to ticket |
| GET | `/api/admin/stats` | 🛡️ | Admin stats |
| GET | `/api/admin/users` | 🛡️ | All users |
| PATCH | `/api/admin/users/:id` | 🛡️ | Edit user |
| GET | `/api/admin/servers` | 🛡️ | All servers |

---

## 📝 License

MIT — build freely, credit appreciated.
