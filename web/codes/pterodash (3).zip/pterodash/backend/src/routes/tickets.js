const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { pool } = require('../db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// GET /api/tickets
router.get('/', authMiddleware, async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const query = isAdmin
      ? `SELECT t.*, u.username as user_name, u.email as user_email,
           (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as message_count
         FROM tickets t JOIN users u ON t.user_id = u.id ORDER BY t.updated_at DESC`
      : `SELECT t.*, u.username as user_name,
           (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as message_count
         FROM tickets t JOIN users u ON t.user_id = u.id
         WHERE t.user_id = ? ORDER BY t.updated_at DESC`;
    const params = isAdmin ? [] : [req.user.id];
    const [tickets] = await pool.query(query, params);
    res.json({ tickets });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/tickets — open new ticket
router.post('/', authMiddleware, [
  body('subject').trim().isLength({ min: 5, max: 255 }),
  body('message').trim().isLength({ min: 10 }),
  body('priority').isIn(['low', 'medium', 'high', 'critical']),
  body('category').trim().isLength({ min: 1, max: 100 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { subject, message, priority, category } = req.body;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const ticketUuid = uuidv4();

    const [result] = await conn.query(
      `INSERT INTO tickets (uuid, user_id, subject, status, priority, category) VALUES (?, ?, ?, 'open', ?, ?)`,
      [ticketUuid, req.user.id, subject, priority, category]
    );

    await conn.query(
      `INSERT INTO ticket_messages (ticket_id, user_id, message, is_admin_reply) VALUES (?, ?, ?, 0)`,
      [result.insertId, req.user.id, message]
    );

    await conn.commit();
    res.status(201).json({ message: 'Ticket created', ticketId: result.insertId, uuid: ticketUuid });
  } catch (err) {
    await conn.rollback();
    console.error('Create ticket error:', err);
    res.status(500).json({ error: 'Failed to create ticket' });
  } finally {
    conn.release();
  }
});

// GET /api/tickets/:id — ticket detail + messages
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const [tickets] = await pool.query(
      `SELECT t.*, u.username as user_name, u.email as user_email FROM tickets t
       JOIN users u ON t.user_id = u.id
       WHERE (t.id = ? OR t.uuid = ?)${!isAdmin ? ' AND t.user_id = ?' : ''}`,
      isAdmin ? [req.params.id, req.params.id] : [req.params.id, req.params.id, req.user.id]
    );
    if (!tickets.length) return res.status(404).json({ error: 'Ticket not found' });

    const [messages] = await pool.query(
      `SELECT m.*, u.username, u.role, u.avatar FROM ticket_messages m
       JOIN users u ON m.user_id = u.id WHERE m.ticket_id = ? ORDER BY m.created_at ASC`,
      [tickets[0].id]
    );
    res.json({ ticket: tickets[0], messages });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/tickets/:id/reply
router.post('/:id/reply', authMiddleware, [
  body('message').trim().isLength({ min: 1 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const isAdmin = req.user.role === 'admin';
    const [tickets] = await pool.query(
      `SELECT * FROM tickets WHERE (id = ? OR uuid = ?)${!isAdmin ? ' AND user_id = ?' : ''}`,
      isAdmin ? [req.params.id, req.params.id] : [req.params.id, req.params.id, req.user.id]
    );
    if (!tickets.length) return res.status(404).json({ error: 'Ticket not found' });
    const ticket = tickets[0];
    if (ticket.status === 'closed') return res.status(400).json({ error: 'Cannot reply to a closed ticket' });

    await pool.query(
      `INSERT INTO ticket_messages (ticket_id, user_id, message, is_admin_reply) VALUES (?, ?, ?, ?)`,
      [ticket.id, req.user.id, req.body.message, isAdmin ? 1 : 0]
    );

    const newStatus = isAdmin ? 'answered' : 'user_replied';
    await pool.query('UPDATE tickets SET status = ?, updated_at = NOW() WHERE id = ?', [newStatus, ticket.id]);

    // Notify the other party
    if (isAdmin) {
      await pool.query(
        `INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'info')`,
        [ticket.user_id, `Ticket #${ticket.id} answered`, `Staff has replied to your ticket: "${ticket.subject}"`]
      );
    }

    res.json({ message: 'Reply sent' });
  } catch (err) {
    console.error('Reply error:', err);
    res.status(500).json({ error: 'Failed to send reply' });
  }
});

// PATCH /api/tickets/:id/close
router.patch('/:id/close', authMiddleware, async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const [tickets] = await pool.query(
      `SELECT * FROM tickets WHERE (id = ? OR uuid = ?)${!isAdmin ? ' AND user_id = ?' : ''}`,
      isAdmin ? [req.params.id, req.params.id] : [req.params.id, req.params.id, req.user.id]
    );
    if (!tickets.length) return res.status(404).json({ error: 'Ticket not found' });
    await pool.query(`UPDATE tickets SET status = 'closed', updated_at = NOW() WHERE id = ?`, [tickets[0].id]);
    res.json({ message: 'Ticket closed' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to close ticket' });
  }
});

module.exports = router;
