const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { pool } = require('../db');
const pterodactyl = require('../services/pterodactyl');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

router.post('/register', [
  body('username').trim().isLength({ min: 3, max: 50 }).matches(/^[a-zA-Z0-9_]+$/).withMessage('Username must be 3-50 alphanumeric chars'),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { username, email, password } = req.body;
  try {
    const [existing] = await pool.query('SELECT id FROM users WHERE username = ? OR email = ?', [username, email]);
    if (existing.length) return res.status(409).json({ error: 'Username or email already taken' });

    const hashed = await bcrypt.hash(password, 12);
    const userUuid = uuidv4();

    const [countRes] = await pool.query('SELECT COUNT(*) as count FROM users');
    const role = countRes[0].count === 0 ? 'admin' : 'user';

    let pteroId = null;
    try {
      const pteroUser = await pterodactyl.createPteroUser({ email, username, firstName: username, lastName: 'User', password });
      pteroId = pteroUser.id;
    } catch (pteroErr) {
      console.warn('Could not create Pterodactyl user:', pteroErr.message);
    }

    const [result] = await pool.query(
      'INSERT INTO users (uuid, username, email, password, role, pterodactyl_id, coins, email_verified) VALUES (?, ?, ?, ?, ?, ?, 500, 1)',
      [userUuid, username, email, hashed, role, pteroId]
    );
    const userId = result.insertId;

    await pool.query(
      'INSERT INTO user_resources (user_id, ram, disk, cpu, servers, databases, backups, allocations) VALUES (?, 1024, 5120, 100, 1, 1, 1, 1)',
      [userId]
    );

    await pool.query(
      'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)',
      [userId, 'Welcome to PteroDash!', 'Your account has been created. You start with 500 coins!', 'success']
    );

    const token = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, message: 'Account created successfully' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { email, password } = req.body;
  try {
    const [rows] = await pool.query(
      'SELECT id, uuid, username, email, password, role, is_banned, ban_reason, coins FROM users WHERE email = ?',
      [email]
    );
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });

    const user = rows[0];
    if (user.is_banned) return res.status(403).json({ error: 'Account banned: ' + (user.ban_reason || 'No reason provided') });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, uuid: user.uuid, username: user.username, email: user.email, role: user.role, coins: user.coins } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/me', authMiddleware, async (req, res) => {
  const [resources] = await pool.query('SELECT * FROM user_resources WHERE user_id = ?', [req.user.id]);
  const [notifCount] = await pool.query('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [req.user.id]);
  res.json({ user: req.user, resources: resources[0] || {}, unreadNotifications: notifCount[0].count });
});

router.post('/change-password', authMiddleware, [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 8 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { currentPassword, newPassword } = req.body;
  try {
    const [rows] = await pool.query('SELECT password FROM users WHERE id = ?', [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, rows[0].password);
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect' });
    const hashed = await bcrypt.hash(newPassword, 12);
    await pool.query('UPDATE users SET password = ? WHERE id = ?', [hashed, req.user.id]);
    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
