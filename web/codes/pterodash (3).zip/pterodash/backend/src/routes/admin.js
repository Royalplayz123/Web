const express = require('express');
const { body, validationResult } = require('express-validator');
const { pool } = require('../db');
const pterodactyl = require('../services/pterodactyl');
const { adminMiddleware } = require('../middleware/auth');

const router = express.Router();
router.use(adminMiddleware);

router.get('/stats', async (req, res) => {
  try {
    const [[{ totalUsers }]] = await pool.query('SELECT COUNT(*) as totalUsers FROM users');
    const [[{ totalServers }]] = await pool.query('SELECT COUNT(*) as totalServers FROM servers');
    const [[{ openTickets }]] = await pool.query("SELECT COUNT(*) as openTickets FROM tickets WHERE status IN ('open','user_replied')");
    const [[{ totalCoins }]] = await pool.query('SELECT SUM(coins) as totalCoins FROM users');
    const [[{ bannedUsers }]] = await pool.query('SELECT COUNT(*) as bannedUsers FROM users WHERE is_banned = 1');
    const [recentUsers] = await pool.query('SELECT id, username, email, role, coins, created_at FROM users ORDER BY created_at DESC LIMIT 5');
    const [recentTickets] = await pool.query('SELECT t.*, u.username FROM tickets t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 5');
    res.json({ stats: { totalUsers, totalServers, openTickets, totalCoins, bannedUsers }, recentUsers, recentTickets });
  } catch (err) {
    console.error('Admin stats error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/users', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const search = req.query.search || '';
    const offset = (page - 1) * limit;
    const searchParam = '%' + search + '%';
    const [users] = await pool.query(
      'SELECT u.id, u.uuid, u.username, u.email, u.role, u.coins, u.is_banned, u.ban_reason, u.pterodactyl_id, u.last_seen, u.created_at, r.ram, r.disk, r.cpu, r.servers, (SELECT COUNT(*) FROM servers s WHERE s.user_id = u.id) as server_count FROM users u LEFT JOIN user_resources r ON r.user_id = u.id WHERE u.username LIKE ? OR u.email LIKE ? ORDER BY u.created_at DESC LIMIT ? OFFSET ?',
      [searchParam, searchParam, limit, offset]
    );
    const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM users WHERE username LIKE ? OR email LIKE ?', [searchParam, searchParam]);
    res.json({ users, total, page, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.patch('/users/:id', async (req, res) => {
  const { coins, role, is_banned, ban_reason, ram, disk, cpu, servers } = req.body;
  try {
    if (coins !== undefined) await pool.query('UPDATE users SET coins = ? WHERE id = ?', [coins, req.params.id]);
    if (role !== undefined) await pool.query('UPDATE users SET role = ? WHERE id = ?', [role, req.params.id]);
    if (is_banned !== undefined) await pool.query('UPDATE users SET is_banned = ?, ban_reason = ? WHERE id = ?', [is_banned ? 1 : 0, ban_reason || null, req.params.id]);
    if (ram !== undefined) await pool.query('UPDATE user_resources SET ram = ? WHERE user_id = ?', [ram, req.params.id]);
    if (disk !== undefined) await pool.query('UPDATE user_resources SET disk = ? WHERE user_id = ?', [disk, req.params.id]);
    if (cpu !== undefined) await pool.query('UPDATE user_resources SET cpu = ? WHERE user_id = ?', [cpu, req.params.id]);
    if (servers !== undefined) await pool.query('UPDATE user_resources SET servers = ? WHERE user_id = ?', [servers, req.params.id]);

    if (is_banned !== undefined) {
      const [userServers] = await pool.query('SELECT pterodactyl_id FROM servers WHERE user_id = ?', [req.params.id]);
      for (const srv of userServers) {
        try {
          is_banned ? await pterodactyl.suspendPteroServer(srv.pterodactyl_id) : await pterodactyl.unsuspendPteroServer(srv.pterodactyl_id);
        } catch {}
      }
    }
    res.json({ message: 'User updated successfully' });
  } catch (err) {
    console.error('Admin update user error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/users/:id/grant-coins', [body('amount').isInt()], async (req, res) => {
  const { amount, reason } = req.body;
  try {
    await pool.query('UPDATE users SET coins = coins + ? WHERE id = ?', [amount, req.params.id]);
    await pool.query('INSERT INTO coin_transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)',
      [req.params.id, amount, amount > 0 ? 'admin_grant' : 'admin_deduct', reason || 'Admin adjustment']);
    await pool.query('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)',
      [req.params.id, amount > 0 ? 'Coins added!' : 'Coins removed!', 'Admin ' + (amount > 0 ? 'added ' : 'removed ') + Math.abs(amount) + ' coins', amount > 0 ? 'success' : 'warning']);
    res.json({ message: 'Coins updated' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/servers', async (req, res) => {
  try {
    const [servers] = await pool.query('SELECT s.*, u.username as owner_name, u.email as owner_email FROM servers s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC');
    res.json({ servers });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/servers/:id/suspend', async (req, res) => {
  try {
    const [[server]] = await pool.query('SELECT * FROM servers WHERE id = ?', [req.params.id]);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    await pterodactyl.suspendPteroServer(server.pterodactyl_id);
    await pool.query('UPDATE servers SET suspended = 1 WHERE id = ?', [server.id]);
    res.json({ message: 'Server suspended' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to suspend server' });
  }
});

router.post('/servers/:id/unsuspend', async (req, res) => {
  try {
    const [[server]] = await pool.query('SELECT * FROM servers WHERE id = ?', [req.params.id]);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    await pterodactyl.unsuspendPteroServer(server.pterodactyl_id);
    await pool.query('UPDATE servers SET suspended = 0 WHERE id = ?', [server.id]);
    res.json({ message: 'Server unsuspended' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to unsuspend server' });
  }
});

router.get('/store', async (req, res) => {
  const [items] = await pool.query('SELECT * FROM store_items ORDER BY category, price');
  res.json({ items });
});

router.post('/store', [
  body('name').trim().isLength({ min: 1 }),
  body('category').isIn(['ram', 'disk', 'cpu', 'servers', 'databases', 'backups', 'allocations']),
  body('amount').isInt({ min: 1 }),
  body('price').isInt({ min: 0 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { name, description, category, amount, price, icon } = req.body;
  const [result] = await pool.query('INSERT INTO store_items (name, description, category, amount, price, icon) VALUES (?, ?, ?, ?, ?, ?)',
    [name, description, category, amount, price, icon || '📦']);
  res.status(201).json({ message: 'Item created', id: result.insertId });
});

router.patch('/store/:id', async (req, res) => {
  const { name, description, price, is_active } = req.body;
  try {
    if (name !== undefined) await pool.query('UPDATE store_items SET name = ? WHERE id = ?', [name, req.params.id]);
    if (description !== undefined) await pool.query('UPDATE store_items SET description = ? WHERE id = ?', [description, req.params.id]);
    if (price !== undefined) await pool.query('UPDATE store_items SET price = ? WHERE id = ?', [price, req.params.id]);
    if (is_active !== undefined) await pool.query('UPDATE store_items SET is_active = ? WHERE id = ?', [is_active ? 1 : 0, req.params.id]);
    res.json({ message: 'Item updated' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/store/:id', async (req, res) => {
  await pool.query('DELETE FROM store_items WHERE id = ?', [req.params.id]);
  res.json({ message: 'Item deleted' });
});

router.post('/announcements', [
  body('title').trim().isLength({ min: 1 }),
  body('content').trim().isLength({ min: 1 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { title, content, type } = req.body;
  await pool.query('INSERT INTO announcements (title, content, type, created_by) VALUES (?, ?, ?, ?)',
    [title, content, type || 'info', req.user.id]);
  res.status(201).json({ message: 'Announcement created' });
});

module.exports = router;
