const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { pool } = require('../db');
const pterodactyl = require('../services/pterodactyl');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// GET /api/servers — list user's servers
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [servers] = await pool.query(
      `SELECT s.*, u.username as owner_name
       FROM servers s
       JOIN users u ON s.user_id = u.id
       WHERE s.user_id = ?
       ORDER BY s.created_at DESC`,
      [req.user.id]
    );

    // Optionally enrich with live Pterodactyl status
    const enriched = await Promise.all(servers.map(async (srv) => {
      try {
        const ptero = await pterodactyl.getPteroServer(srv.pterodactyl_id);
        return { ...srv, pterodactyl_status: ptero.status };
      } catch {
        return srv;
      }
    }));

    res.json({ servers: enriched });
  } catch (err) {
    console.error('List servers error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/servers/options — nodes, nests, eggs for creation wizard
router.get('/options', authMiddleware, async (req, res) => {
  try {
    const [nodes, nests, locations] = await Promise.all([
      pterodactyl.listPteroNodes(),
      pterodactyl.listNests(),
      pterodactyl.listLocations(),
    ]);
    res.json({ nodes, nests, locations });
  } catch (err) {
    console.error('Options error:', err);
    res.status(500).json({ error: 'Failed to fetch panel options' });
  }
});

// GET /api/servers/eggs/:nestId
router.get('/eggs/:nestId', authMiddleware, async (req, res) => {
  try {
    const eggs = await pterodactyl.getNestEggs(req.params.nestId);
    res.json({ eggs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch eggs' });
  }
});

// GET /api/servers/:id
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const [servers] = await pool.query(
      'SELECT * FROM servers WHERE (id = ? OR uuid = ?) AND user_id = ?',
      [req.params.id, req.params.id, req.user.id]
    );
    if (!servers.length) return res.status(404).json({ error: 'Server not found' });
    const server = servers[0];

    let pteroData = null;
    try {
      pteroData = await pterodactyl.getPteroServer(server.pterodactyl_id);
    } catch {}

    res.json({ server, pterodactyl: pteroData });
  } catch (err) {
    console.error('Get server error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/servers — create server
router.post('/', authMiddleware, [
  body('name').trim().isLength({ min: 1, max: 100 }),
  body('nodeId').isInt(),
  body('nestId').isInt(),
  body('eggId').isInt(),
  body('ram').isInt({ min: 128 }),
  body('disk').isInt({ min: 512 }),
  body('cpu').isInt({ min: 10 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { name, description, nodeId, nestId, eggId, ram, disk, cpu, databases = 0, backups = 0 } = req.body;

  try {
    // Check user resources
    const [resources] = await pool.query('SELECT * FROM user_resources WHERE user_id = ?', [req.user.id]);
    const res_ = resources[0];
    if (!res_) return res.status(400).json({ error: 'Resources not found for user' });

    const [serverCount] = await pool.query('SELECT COUNT(*) as count FROM servers WHERE user_id = ?', [req.user.id]);
    if (serverCount[0].count >= res_.servers) {
      return res.status(400).json({ error: `Server slot limit reached (${res_.servers} max)` });
    }
    if (ram > res_.ram) return res.status(400).json({ error: `Not enough RAM. You have ${res_.ram}MB available.` });
    if (disk > res_.disk) return res.status(400).json({ error: `Not enough disk. You have ${res_.disk}MB available.` });
    if (cpu > res_.cpu) return res.status(400).json({ error: `Not enough CPU. You have ${res_.cpu}% available.` });

    // Get egg details
    const egg = await pterodactyl.getEgg(nestId, eggId);

    // Get free allocation on node
    const freeAlloc = await pterodactyl.getFreeAllocation(nodeId);
    if (!freeAlloc) return res.status(400).json({ error: 'No free ports available on this node' });

    // Build environment from egg variables
    const environment = {};
    if (egg.relationships?.variables?.data) {
      for (const v of egg.relationships.variables.data) {
        environment[v.attributes.env_variable] = v.attributes.default_value || '';
      }
    }

    // Create on Pterodactyl
    const pteroServer = await pterodactyl.createPteroServer({
      name,
      userId: req.user.pterodactyl_id,
      eggId,
      nestId,
      allocationId: freeAlloc.id,
      ram,
      disk,
      cpu,
      databases,
      backups,
      environment,
      startupCommand: egg.startup,
      dockerImage: egg.docker_image,
    });

    // Save in DB
    const serverUuid = uuidv4();
    const [result] = await pool.query(
      `INSERT INTO servers (uuid, user_id, pterodactyl_id, pterodactyl_uuid, name, description, node_id, allocation_id, egg_id, nest_id, ram, disk, cpu, databases, backups, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'installing')`,
      [serverUuid, req.user.id, pteroServer.id, pteroServer.uuid, name, description || '', nodeId, freeAlloc.id, eggId, nestId, ram, disk, cpu, databases, backups]
    );

    // Deduct resources from pool
    await pool.query(
      `UPDATE user_resources SET ram = ram - ?, disk = disk - ?, cpu = cpu - ?, databases = databases - ?, backups = backups - ? WHERE user_id = ?`,
      [ram, disk, cpu, databases, backups, req.user.id]
    );

    await pool.query(
      `INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'success')`,
      [req.user.id, `Server "${name}" created!`, 'Your server is being installed. It will be ready in a moment.']
    );

    res.status(201).json({ message: 'Server created successfully', serverId: result.insertId, uuid: serverUuid });
  } catch (err) {
    console.error('Create server error:', err);
    res.status(500).json({ error: err.message || 'Failed to create server' });
  }
});

// DELETE /api/servers/:id
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const [servers] = await pool.query(
      'SELECT * FROM servers WHERE (id = ? OR uuid = ?) AND user_id = ?',
      [req.params.id, req.params.id, req.user.id]
    );
    if (!servers.length) return res.status(404).json({ error: 'Server not found' });
    const server = servers[0];

    // Delete from Pterodactyl
    try {
      await pterodactyl.deletePteroServer(server.pterodactyl_id);
    } catch (e) {
      console.warn('Pterodactyl delete warning:', e.message);
    }

    // Return resources
    await pool.query(
      `UPDATE user_resources SET ram = ram + ?, disk = disk + ?, cpu = cpu + ?, databases = databases + ?, backups = backups + ? WHERE user_id = ?`,
      [server.ram, server.disk, server.cpu, server.databases, server.backups, req.user.id]
    );

    await pool.query('DELETE FROM servers WHERE id = ?', [server.id]);
    res.json({ message: 'Server deleted successfully' });
  } catch (err) {
    console.error('Delete server error:', err);
    res.status(500).json({ error: 'Failed to delete server' });
  }
});

// POST /api/servers/:id/reinstall
router.post('/:id/reinstall', authMiddleware, async (req, res) => {
  try {
    const [servers] = await pool.query(
      'SELECT * FROM servers WHERE (id = ? OR uuid = ?) AND user_id = ?',
      [req.params.id, req.params.id, req.user.id]
    );
    if (!servers.length) return res.status(404).json({ error: 'Server not found' });
    await pterodactyl.reinstallPteroServer(servers[0].pterodactyl_id);
    res.json({ message: 'Server reinstall triggered' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to reinstall server' });
  }
});

module.exports = router;
