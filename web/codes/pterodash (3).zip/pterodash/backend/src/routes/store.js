const express = require('express');
const { pool } = require('../db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

router.get('/', authMiddleware, async (req, res) => {
  try {
    const [items] = await pool.query('SELECT * FROM store_items WHERE is_active = 1 ORDER BY category, price');
    res.json({ items });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/buy/:itemId', authMiddleware, async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [[item]] = await conn.query('SELECT * FROM store_items WHERE id = ? AND is_active = 1', [req.params.itemId]);
    if (!item) return res.status(404).json({ error: 'Item not found or unavailable' });

    const [[user]] = await conn.query('SELECT coins FROM users WHERE id = ? FOR UPDATE', [req.user.id]);
    if (user.coins < item.price) {
      await conn.rollback();
      return res.status(400).json({ error: 'Not enough coins. Need ' + item.price + ', have ' + user.coins + '.' });
    }

    await conn.query('UPDATE users SET coins = coins - ? WHERE id = ?', [item.price, req.user.id]);

    const resourceMap = {
      ram: 'ram', disk: 'disk', cpu: 'cpu',
      servers: 'servers', databases: 'databases',
      backups: 'backups', allocations: 'allocations',
    };
    const col = resourceMap[item.category];
    if (col) {
      await conn.query('UPDATE user_resources SET ' + col + ' = ' + col + ' + ? WHERE user_id = ?', [item.amount, req.user.id]);
    }

    await conn.query(
      "INSERT INTO coin_transactions (user_id, amount, type, description, reference_id) VALUES (?, ?, 'purchase', ?, ?)",
      [req.user.id, -item.price, 'Purchased: ' + item.name, 'store_item_' + item.id]
    );

    await conn.query(
      "INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'success')",
      [req.user.id, 'Purchase successful!', 'You bought "' + item.name + '" for ' + item.price + ' coins.']
    );

    await conn.commit();

    const [[updated]] = await pool.query('SELECT coins FROM users WHERE id = ?', [req.user.id]);
    res.json({ message: 'Successfully purchased ' + item.name + '!', newCoins: updated.coins });
  } catch (err) {
    await conn.rollback();
    console.error('Buy error:', err);
    res.status(500).json({ error: 'Purchase failed' });
  } finally {
    conn.release();
  }
});

router.get('/transactions', authMiddleware, async (req, res) => {
  try {
    const [transactions] = await pool.query(
      'SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
      [req.user.id]
    );
    res.json({ transactions });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
