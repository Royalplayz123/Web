const axios = require('axios');

const pteroClient = axios.create({
  baseURL: `${process.env.PTERODACTYL_URL}/api/application`,
  headers: {
    Authorization: `Bearer ${process.env.PTERODACTYL_API_KEY}`,
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// ── Users ──────────────────────────────────────────────────────────────────

async function createPteroUser({ email, username, firstName, lastName, password }) {
  const res = await pteroClient.post('/users', {
    email,
    username,
    first_name: firstName,
    last_name: lastName || 'User',
    password,
  });
  return res.data.attributes;
}

async function getPteroUser(pteroId) {
  const res = await pteroClient.get(`/users/${pteroId}`);
  return res.data.attributes;
}

async function listPteroUsers() {
  const res = await pteroClient.get('/users?include=servers');
  return res.data.data.map(u => u.attributes);
}

async function updatePteroUser(pteroId, data) {
  const res = await pteroClient.patch(`/users/${pteroId}`, data);
  return res.data.attributes;
}

async function deletePteroUser(pteroId) {
  await pteroClient.delete(`/users/${pteroId}`);
}

// ── Servers ────────────────────────────────────────────────────────────────

async function createPteroServer({ name, userId, eggId, nestId, allocationId, ram, disk, cpu, databases = 0, backups = 0, environment = {}, startupCommand, dockerImage }) {
  const res = await pteroClient.post('/servers', {
    name,
    user: userId,
    egg: eggId,
    docker_image: dockerImage,
    startup: startupCommand,
    environment,
    limits: {
      memory: ram,
      swap: 0,
      disk,
      io: 500,
      cpu,
    },
    feature_limits: {
      databases,
      backups,
      allocations: 1,
    },
    allocation: {
      default: allocationId,
    },
  });
  return res.data.attributes;
}

async function getPteroServer(pteroId) {
  const res = await pteroClient.get(`/servers/${pteroId}`);
  return res.data.attributes;
}

async function listPteroServers() {
  const res = await pteroClient.get('/servers?include=allocations');
  return res.data.data.map(s => s.attributes);
}

async function suspendPteroServer(pteroId) {
  await pteroClient.post(`/servers/${pteroId}/suspend`);
}

async function unsuspendPteroServer(pteroId) {
  await pteroClient.post(`/servers/${pteroId}/unsuspend`);
}

async function deletePteroServer(pteroId) {
  await pteroClient.delete(`/servers/${pteroId}`);
}

async function reinstallPteroServer(pteroId) {
  await pteroClient.post(`/servers/${pteroId}/reinstall`);
}

// ── Nodes ──────────────────────────────────────────────────────────────────

async function listPteroNodes() {
  const res = await pteroClient.get('/nodes?include=allocations');
  return res.data.data.map(n => n.attributes);
}

async function getPteroNode(nodeId) {
  const res = await pteroClient.get(`/nodes/${nodeId}`);
  return res.data.attributes;
}

async function getNodeAllocations(nodeId) {
  const res = await pteroClient.get(`/nodes/${nodeId}/allocations`);
  return res.data.data.map(a => a.attributes);
}

async function getFreeAllocation(nodeId) {
  const allocations = await getNodeAllocations(nodeId);
  const free = allocations.find(a => !a.assigned);
  return free || null;
}

// ── Eggs / Nests ───────────────────────────────────────────────────────────

async function listNests() {
  const res = await pteroClient.get('/nests');
  return res.data.data.map(n => n.attributes);
}

async function getNestEggs(nestId) {
  const res = await pteroClient.get(`/nests/${nestId}/eggs?include=config,variables`);
  return res.data.data.map(e => e.attributes);
}

async function getEgg(nestId, eggId) {
  const res = await pteroClient.get(`/nests/${nestId}/eggs/${eggId}?include=config,variables`);
  return res.data.attributes;
}

// ── Locations ─────────────────────────────────────────────────────────────

async function listLocations() {
  const res = await pteroClient.get('/locations?include=nodes');
  return res.data.data.map(l => l.attributes);
}

module.exports = {
  createPteroUser,
  getPteroUser,
  listPteroUsers,
  updatePteroUser,
  deletePteroUser,
  createPteroServer,
  getPteroServer,
  listPteroServers,
  suspendPteroServer,
  unsuspendPteroServer,
  deletePteroServer,
  reinstallPteroServer,
  listPteroNodes,
  getPteroNode,
  getNodeAllocations,
  getFreeAllocation,
  listNests,
  getNestEggs,
  getEgg,
  listLocations,
};
