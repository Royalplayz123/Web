-- PteroDash Database Schema
-- Run this file once to set up your database

CREATE DATABASE IF NOT EXISTS pterodash CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pterodash;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(36) UNIQUE NOT NULL,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  pterodactyl_id INT DEFAULT NULL,
  coins INT DEFAULT 500,
  role ENUM('user', 'admin', 'moderator') DEFAULT 'user',
  is_banned TINYINT(1) DEFAULT 0,
  ban_reason VARCHAR(500) DEFAULT NULL,
  avatar VARCHAR(500) DEFAULT NULL,
  discord_id VARCHAR(100) DEFAULT NULL,
  github_id VARCHAR(100) DEFAULT NULL,
  email_verified TINYINT(1) DEFAULT 0,
  last_seen DATETIME DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- User resources table (limits assigned to each user)
CREATE TABLE IF NOT EXISTS user_resources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  ram INT DEFAULT 1024,        -- MB
  disk INT DEFAULT 5120,       -- MB
  cpu INT DEFAULT 100,         -- percent
  `servers` INT DEFAULT 1,
  `databases` INT DEFAULT 1,
  `backups` INT DEFAULT 1,
  `allocations` INT DEFAULT 1,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Servers table (mirrors Pterodactyl + extra meta)
CREATE TABLE IF NOT EXISTS servers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(36) UNIQUE NOT NULL,
  user_id INT NOT NULL,
  pterodactyl_id INT UNIQUE NOT NULL,
  pterodactyl_uuid VARCHAR(36) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT DEFAULT NULL,
  node_id INT DEFAULT NULL,
  allocation_id INT DEFAULT NULL,
  egg_id INT DEFAULT NULL,
  nest_id INT DEFAULT NULL,
  ram INT DEFAULT 512,
  disk INT DEFAULT 1024,
  cpu INT DEFAULT 100,
  `databases` INT DEFAULT 0,
  `backups` INT DEFAULT 0,
  `allocations` INT DEFAULT 1,
  status ENUM('installing', 'running', 'offline', 'suspended') DEFAULT 'installing',
  suspended TINYINT(1) DEFAULT 0,
  renewal_date DATETIME DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Store items table
CREATE TABLE IF NOT EXISTS store_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  category ENUM('ram', 'disk', 'cpu', 'servers', 'databases', 'backups', 'allocations') NOT NULL,
  amount INT NOT NULL,
  price INT NOT NULL,
  icon VARCHAR(50) DEFAULT '📦',
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Coin transactions
CREATE TABLE IF NOT EXISTS coin_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amount INT NOT NULL,
  type ENUM('earn', 'spend', 'admin_grant', 'admin_deduct', 'purchase', 'renewal') NOT NULL,
  description VARCHAR(500) NOT NULL,
  reference_id VARCHAR(100) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tickets table
CREATE TABLE IF NOT EXISTS tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(36) UNIQUE NOT NULL,
  user_id INT NOT NULL,
  subject VARCHAR(255) NOT NULL,
  status ENUM('open', 'answered', 'user_replied', 'closed') DEFAULT 'open',
  priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  category VARCHAR(100) DEFAULT 'General',
  assigned_to INT DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);

-- Ticket messages
CREATE TABLE IF NOT EXISTS ticket_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT NOT NULL,
  user_id INT NOT NULL,
  message TEXT NOT NULL,
  is_admin_reply TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
  is_read TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Announcements (admin broadcasts)
CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  type ENUM('info', 'warning', 'success', 'danger') DEFAULT 'info',
  is_active TINYINT(1) DEFAULT 1,
  created_by INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed default store items
INSERT IGNORE INTO store_items (name, description, category, amount, price, icon) VALUES
('256 MB RAM', 'Adds 256MB of RAM to your resource pool', 'ram', 256, 100, '🧠'),
('512 MB RAM', 'Adds 512MB of RAM to your resource pool', 'ram', 512, 190, '🧠'),
('1 GB RAM', 'Adds 1024MB of RAM to your resource pool', 'ram', 1024, 360, '🧠'),
('2 GB RAM', 'Adds 2048MB of RAM to your resource pool', 'ram', 2048, 700, '🧠'),
('5 GB Disk', 'Adds 5GB of disk space to your resource pool', 'disk', 5120, 75, '💾'),
('10 GB Disk', 'Adds 10GB of disk space to your resource pool', 'disk', 10240, 140, '💾'),
('25 GB Disk', 'Adds 25GB of disk space to your resource pool', 'disk', 25600, 330, '💾'),
('50 GB Disk', 'Adds 50GB of disk space to your resource pool', 'disk', 51200, 600, '💾'),
('50% CPU', 'Adds 50% vCPU to your resource pool', 'cpu', 50, 75, '⚡'),
('100% CPU', 'Adds 100% vCPU to your resource pool', 'cpu', 100, 140, '⚡'),
('1 Server Slot', 'Allows creation of one more server', 'servers', 1, 200, '🖥️'),
('1 Database Slot', 'Adds one MySQL database slot', 'databases', 1, 50, '🗄️'),
('1 Backup Slot', 'Adds one backup slot to your account', 'backups', 1, 80, '📦'),
('1 Allocation', 'Adds one port allocation to your account', 'allocations', 1, 40, '🌐');

-- Seed default admin user (password: Admin@1234 - CHANGE THIS!)
INSERT IGNORE INTO users (uuid, username, email, password, role, coins, email_verified) VALUES
(UUID(), 'admin', 'admin@pterodash.local', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2NqdBEpMaO', 'admin', 9999, 1);

INSERT IGNORE INTO user_resources (user_id, ram, disk, cpu, `servers`, `databases`, `backups`, `allocations`)
SELECT id, 16384, 102400, 1600, 20, 20, 20, 20 FROM users WHERE username = 'admin';
